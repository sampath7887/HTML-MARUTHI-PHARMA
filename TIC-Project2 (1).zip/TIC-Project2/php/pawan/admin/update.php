<?php
include('config.php');
session_start();
$name="";
$ph;
$message="";
$email="";
$is;
$date;
$ip;
$_SESSION;
$id=$_GET['id'];

	include("../login/connection.php");
	require("../login/functions.php");

$sql ="SELECT `EmailId`, `FullName`, `id`, `Is_Read`, `Message`, `PhoneNumber`, `PostingDate`, `UserIp` FROM `tblcontactdata` WHERE  id=$id";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0):
foreach($results as $result):
 $name=$result->FullName;
 $ph = $result->PhoneNumber;
 $message=$result->Message;
  $email=$result->EmailId;
    $is=$result->Is_Read;
	$date=$result->PostingDate;
    $ip=$result->UserIp;
		

	


endforeach;
endif
?>
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title> Admin </title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script><script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



</head>

<body>

<?php error_reporting(0);
include('config.php');
 ?>
<center>

<!-- NAVIGATION-->
<nav class="navbar navbar-expand-lg navbar-light bg-light py-3 ">
  <div class="container">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">


      	  <li class="nav-item">

	    <?php

	  if( isset($_SESSION["id"]) ){
 echo  '  <li class="nav-item">  Welcome, ' .$_SESSION["name"]. " </li>  ";
	  }
	  
	   ?>
	   	   </li>

	  <li class="nav-item">
  <a class="nav-link" href="../admin/controls.php">Back</a>   
	   </li>



    </div>
  </div>
</nav>
</nav>
<!----------------------------------------------------------------------------------------- -->


	 				<center><h3>update data</h3></center>

						
						
							
						
					<form name="ContactForm" id="form1" method="post">

<h4> name</h4>
<input type="text" name="name"  id="name1" value="<?php echo $name;?>"  autocomplete="off" required>


<h4> phone number</h4>
<input type="text" name="phonenumber" id="phone"  value="<?php echo $ph;?>" maxlength="10" required autocomplete="off">

<h4> email address</h4>
<input type="email" name="emailaddres" id="email" value="<?php echo $email;?>" required autocomplete="off">


<h4> message</h4>
<textarea id="mess" name="message"   required> <?php echo $message;?></textarea><br>



  <input type="submit" id="submit" class="submit" value="update"  name="submit">
  
  

</form>


		<?php
if ($_POST['submit']) {
	
	
	$name1 = $_POST['name'];
		$ph1 = $_POST['phonenumber'];
	$email1 = $_POST['emailaddres'];
	$message1 = $_POST['message'];






 $sql="INSERT INTO  tblcontactdata(FullName,PhoneNumber,EmailId,Message,Is_Read) VALUES(:fname,:phone,:email,:message,:isread)";
$query = $dbh->prepare($sql);
// Bind parameters
$query->bindParam(':fname',$name1,PDO::PARAM_STR);
$query->bindParam(':phone',$ph1,PDO::PARAM_STR);
$query->bindParam(':email',$email1,PDO::PARAM_STR);
$query->bindParam(':message',$message1,PDO::PARAM_STR);
$query->bindParam(':isread',$is,PDO::PARAM_STR);
$query->execute();


$sql ="DELETE FROM `tblcontactdata` WHERE id = :id";
$query = $dbh -> prepare($sql);
$query->bindParam(':id',$id,PDO::PARAM_STR);
$query->execute();

  echo "<script>window.location.href='../admin/controls.php'</script>";
 
 }

?>

<div>
		<a href="https://play.google.com/store/apps/details?id=com.whatsapp&hl=en_IN&gl=US">
		<img class="whats" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAwFBMVEX19fUYnQ739/f//f8AkwAAlQDz8/Pt7e0AlgAAmQDw8PD/+////v8YnA7p6en09fQAjwD29Pf1+PTk5OTu9O3V6NR7vnkXlw3/+f8hoRmCwH91uHPf7d2t1azM5cqy17GNxYuQxpBotWdTrVFJqEfI4seaypgmnCJqtmmk0KLb69rv9e8yojDp9Og+pju93L5fslubx5sAhgCMx4jF2MSKwItPrE7T49I/pD81oDO42bcjlB4knh9ytXLc79qczpmv0AT9AAAUsUlEQVR4nO0diXbiSM7I5YvyQTkQSEICSchBgCQz2e1OZ7Od//+rlYrDZWyDD+xM70Pz3ryeaWxZJZXuUmnaEY5whCMc4QhHOMIRjnCEIxxhBwD+0yg+hKYRNksiWJbZKD7Tt5pdUktrN4gRMVngmw2SCGCZVrvdIMK26cNJg0vq+5av+Y0hRBFtn2hWcysKFrTbDXIQUERJZhpdUattak2pNjDbbR8akxgwzbZlniwRNoCU+HcCJ2ZjIoo26cT0Ta1BEW3TcrabM01goYZBEhszv7QDpVJrDJ+PBFrN+TOm75tmg5YQdShoJw36ayiguC2aQ0haDbe+pTWGkii0UEYrIMz/JKLxLcvyLa2Ku1bgUSARbfu4DyutZxGM6IkiNquSZSryLJoJ1DNofRuiEExSaVUNfaGH0Y1BrE1tCbDQkfGbwbUEktAm4xcUUWg0XqLNYDYZg6Kn1pxvKClsQ7Ugu/DHwolVBV9hhKjSmosmlhgrBYQlHsWd33TyqYrMlPnUSgiPcIQjHOEfDEFA/zYDTWhCcAkDHYSQfym+9dMOBoEQA851HZ6uRl/jt7e38fSltwBd51w0XT2pAQTXXff3x/hmbrMOM2wHwbYN/HNrcnF/N3M5/4NpFMD1xcf5hHUMpKu1DUgq63gX0986BxFowXd/bmHgOvSu54axpM1LELim02be6V3IxZ+zJyU3UDh7F5+GvaTC20GhpJJ5N3fuHySupuCL6S+WlMudRM6/FlyYwR9AJgi3d4PCWYQ+yWPbuOnpDclq2YI0KQvhXk2KsU9hZOfmt4t8PCw1SQALoRSNQYD0PRemz+v3+96axluk8eAkbYHZtrRyKU7Be68l+Nf3+q3+Wh05nYtu3TrHapsyGV8IgKxfeI70eTv1ppOwjF6rjwR6nrf+T8eYunzt7tUDlAZsFxVTAP2jn8k/tO6GwezP+a/3919zD50a8m7kWnjEQ6+vrgub/OZBjU4rtK0SBWJ9dsMyqLOZPX+8H/W63VAncMNu92p0//pAXlwrtg9XfHTYl16npBZWpShP6QxEkWP26/Rn1yU3W2jEGJI+AHTGdX3R+3rPsCtssuBak90iO4FU6HkaAx1mnF+FOoUQaU8FANztfrwy5iS9Hofd6f8YXzUYdN+NhH5xDOP8t8vRpyZi0p80kUqhhy+vHTu5Pp2x3iwdWRAC7yUlFL2wKfCcykK4i3PHSLCR3WDM8f1sDAT/YEkRm9zpXMudvgyQkdO+vU2j/dwV305hoOnTxBY03l/cQkoCeY3W9N6OiwLqqQfUN98MQr9m8a9q2d7ILfVdfHa67RE5zpB/LxsD/W2Lg07nPORmGWuNz7g9VFnx19nDwcG/Oj8EmjvuxDeP/YARUABllh1DZxP0+47CRo+29JB/o7rR77c42DkNKzpb/PezrS6Z53iLb0twBINRnEDH+NCr7poA+GN8ZzsPs28hESkRV1sE/jqE5kNH55KtRJT+jRr1R8Mt4usueBjGtbt9W1VClxAE/M52PEVU7Ue3WQcOLNkk7j7ECGSnB3KykBa+iHlJ3t9/NWgWUWCoKd3U3MeYL2m8HW6dcQN01eXrt/7+KZrjIlCjDFirzbJeZTZ2D2qZxWzutJaSKpMAHWgsKy6b0ts+DGNahr3pBzZaMFtxkeLjft94bSTQANkQSyIq9Gd1oxgXbo5ni4GgveiRiPaJl53LgluxTDMH9TRShgM3Iv9SWejgAocHR8ifKKDyKE8lN2NBw1+umcOiHuq2H4ih0YrUuTMP90tocYTAXzpen0jsr5ex0OOFEdJDaCV8oJBwEsmo17IXUI/Twe//bkU5KnZXyt0tACiibZPaxIV4MSJ77LG7QT2ucQCDR+LiGtNn3cqGsv1IIgQQqvbYuE6oAEnvkuoKpAfCb4tP5m1kxfiqN5CioxrUJE7Cs7H16DT+SlOjgnOZPwwqiC8gPvEvNV60Z3VGw9DWVk3iWhg5M16rM0zBqnc/rv/91+iqW8HZMnFHgDUYK56Tc16bnAL1/floKUjR8C9lXY377ZJfgBt2TMVtx2DOHS8tpz4hbFthX3UsastMmSD7YTUkMdBCprj9fTehlsH9sVqCs1Y/hHLfRMcjTR9NE39RLK9znTdBWRgfraa0+LjDpkr2l70kMII+WQqWd+adGdNBKQJRQv3lQV7QXxW1Zof1eKfUXbxsEkdjqH9GGBNWGNG7p8sVQAK9s7P+XncuFSzaFUvpgCclHWtMeS0UoqONnprEF8SkhvUSTSLrAB2pIyKNjxJSiipbHn6hP4dCP1WW9GGfd1gOcDtsOpr1WwXfTaJ4ArN1hwmShxvRuS2l/vzNEVc0OAtFs7G7ejYirE9+AywUFhpP2+gCfh4tAHIRY4JeGSdfO1lX1qhy96guqluPNqUThBLQ2kce923C3Ak1bPTOKFN2UcommkqffxC9FJ3gbk32Yl01dd+dDYWdpMTw6+0qlMdK7Ry1aTHgijpF7VyWhjwQiCe2WU3n1/YWC0z3M1Fns6eVc9ZR2hKxTurtKuJvEQvx07f+FhfA2CYQo8dyBkN5raYrrpvdrfi63bjcZ2djnFgyPcq/Umq57KqiNyk0PlbE9KXOzKKquJ3XBG8C1HrJZhq0KVVT1uKpE73usc4wkX9EFBqjpCZ152mNFU51udKV9KlTVep3Ab+IEHXCZCrETW2HMhIbtjjie0VMf9eoahQKnEnS9Ao9tTfGea4sV6IXmUR7VD4k2wdqGthJY0w6hS2jsjMZQKTCaoyDNfGy3oZei/1MUR/6ZyqFD3rlQwfoDq/lJz1vcggIND61NxQas5SfuJM0Jtpv1fW7Yoc8dtgSSQRoeCNF4zynLaTqdysUzqoXOCHaiK1OwuE/FATuXN0MsXWUbmvAR4nuL5TnpFkpDqIbbURp8+soCwfC7axLzy07/tkgJ/qIYJFs4DMOoxjU1b3nlFepsrcz2i9h0YlctqdYw6G5zBUnN6LnTPZ3f+Vp91QibwzIMJozKxzczpibEaidCUZX3QtAwz1o6A2/3+74edhf3M81S0bJZTi3ulnttH8WhaD4bA8x0aNT1HLiXCzjIDfhcL9WyEXhYKPHMVohCrUK8xOyjsyRsVifGniOmTga5WXKTI7q19HvTnO0weaikJTY5q16YNH0qdwU5QUlhnFu430JsJodFsAipk2d8aFCHXEVUWjzgCrRh9emirVLJEo3cq1fxEJE71AdGmoGiEFQzwATdbNfpEsfYg7jbUT3/DDCBMoO79RUkQ1UlybbyPFRvA1lcZjFFl2VwoO8MgEBz0UhpeNUXTM5kJ+sODV1UahmZndRSDGWegCmevwr39qNErW1UZiTh8CvFWWDJrFM1jv51gZ4GPC4psn8XaydyKP+0AN8kappWG08PF9HoR7VZDIh2GoJc14PEdApTj0LayIRLf4mzr7dqT+4ekIBo+UdHM8Loqek+WrjoeIavu/WkO5NvPd0XFmhRhkUxF5XThiURqGHnZ8cQPgZyw13vvTs84Q5zDdo/DL38pYGip6icvOe7nJZm9782vPYV6agQj7Pe6y6jHVV2JTNbuyLivgoSsQvBTWdRAhHL3mO2LiKMT6trXLhdjYtWMbLPvXovsWDYXbjpjALhobBPqewtwFh4yl55OvWxUN3vnFWMCza7VGDpr/GC1H2PHlYQczkSSfD+Ar13Z3cbtQ5xPaublkwN663LFTu/C3QaJPbmG/TcoxR/EhbAK70DbyWZ9vjBZU+M7q5ZUfrRm0Nazt+we8jBZmjAiTCX1t5KfY4G4SbLlF0fk6VsJadLlzIGnEiRhs97rH6ik+quWC9fUoeY8VunERkvXep+Dfy6OLmaEzLth+HWaXGKHLznB/1USgUZWrv7ywPAt5N1PXZpIdUEJEB70UZj+XJfIddLPS0ptRA2YbOdV2KRotX13K1XUP3IZFAZT+uONlA0bW3/44O452GKRF81CGBaukjnw9YauA1j4xSri6SUBvMNiRu2OWwyUuo8/A5pSROR9VSXqxHHk2LLXLlaMppo4Fa5f7Y29hCwgTuROYg+6uW+6U0Gvbp2E4jkCi4SvJQ/6G0WuXYhnJKc5nLH2TCF3X72dkZBlB5NnwgNHikZem31NEQSGTmDA0jGTFT+LuxxPk8mra8PqAwhQFfxrZnrTPPw0h7v89Mc+joMLQ8GLJzWFRE4XbtFd3uqXO2fti4y/HdQD3GpUbgrjqGkIVnpE3367RA1h0/OrYipXuAbRt0fMHzikIS9xzhL9DZrHJTtqlQeSbBK9CAAGLxHyMfA4lJ20OGQAztszWFeXQ4kIiWneWvz0lEl5siZ68naJbvuxdbh76zwEuJjdzT9ZFSL62NZxuf7LovXZlCx02KKEFK92UKmCgxKDWDFzulIyxNSF8GWz49dKNWs5azt9Pbtyyz7ZeeJA5DRiK6HJXEcvTuAFJHJzWAhzQxwdvHR2fuii2DqLQLes7es7hAN7BUuB0BpGVazYLK0bBL3b4mlRaDQON3v5KtiwkWbuuvAGZqfnmvO2zR8TrZdV9WTD+caEMhvn0kUse2uZo6JdwpnZjaxcfELsQARDk2k+xp3QLcg6ZfaRZ8oIWboVWel9KfuI3QlJ33a+CzsbNrOzrzRP5HTQW3jD0WCjb3W5QlUIt3etOZwF34TN9EHtJ9E5uf6eH9cjRUnJFLW+DMuwkClWoJbo7dXQGr43XUI16eRNBmyqkg2TiUsarkV+Cet+LlaNyO4eV7JzHyU2qum21rDrGePcrQ7PoyutzCksdtSpMnQT9X5KzzlP02eT0CXUwU/wnS6D6NPzux2Iliw8/kVA2IdZa2OjtZCHTRmlntSpTli2bKxrCzj+mYdAfLMkpTUUo/DpDI6a3H6IibBMN4/XCTrwr0qboLk4c51e+Sp+ilTqtIYuzUiHOT1exJfq+ffbEUGkg9fBrd30ze399v/z3q6mnBmBr5kku647OAjitWvGJm8y4V7UOG+gbL2n2/Bckbkam7rqtzkT4nEdS2anvXUQs0vHQ1URUClWdnqsLPGqawHBKa/b7VU8tZbkHKWCKaAKJseRn87zAVdH/doW4MIT8xUqaZNQSofKEGv1QPc7KrfV5Kpauz1GfhKcqRORfZVRKockcJ4H7/HR/c4IqdU4aBrgI9CAQDJS1kj2oaUhkIdGZUe9JPOAO1gdD/q5xJOFC7TAICOb9FMYWH6MPNi9tVtmHlQ01ZIE+nKM7TrsaBg+NWWq6Tp7sOAkEgwngv7mfY4CUDykiFFlvUkmAXIozNv2l1rpqc9qVPopaM51pGUwdioXqj3qH6qvKBCN3ISDlvdRRJgD/FB6Lar26DgwVDcacUSV5q6IMU+kd8BKYzqX+IuQrqUV+je/jtL9zx9lTBhue0Rk1rnjPRDzwAAGPHxSSe5qDJkI0SqFZJnb+2x6fSjTJVskCgX25Pv2a9+g7jpX6Deow0Su0BfZ3g7uJjfH/lQrmBToGmD29ZS8lu0BSz3zVWfFNBKZK2vEhGBde7d+MHCtrZ/K74jE+gsZ7hmDnxVKNj9MoNR6kAoBTUVx0nYuBC7+vZZqsin8Nue8W1H+eXiby/Y6dNMKoMII+/ZOwmMYysoX2va5SL6E1vPm0n5kUyed1Irq8LtKBtWW54Od9KiHst+31RDwcp5ZhFIp9G2VLWc/XF5c0Zsx2qZLTO1NVnt1d8T5vTCoK2GHT/8pLz9Y0fM6hFybTlPcxZfS3K8Jaz0eOc2eui8LoitVYRDnsYd939U49AFy83dkzBrBbwtKYbWaBN11tkUahmElvRsnvLoukW2Ox1hERCAGbSblJqBrUv9M5Zx45u8FivkNO5rKvHkia10D0saSQKtStqa9Ok/l/H7jxc091jg3gKBQQM6Mqr6S1djEDDEbcHzs+HvJ5xQhJ9u52RVA3oYJDaURH9MfvyFYcZ89Ppz+HCdSlzSACL4c/p+bONtoWe87Z7GBx2DtDg1FmVwu1evHwgL2Ex+g/P75Mfk/f5Z9+Ql8xl/dyeX9V6RckO2DpAWQjkRUBL2P0rxxiH3zZLX3XZskjY/LkcOOx18Y03d+g3O9afbsG7OH9ndln6pIn5cVXs4ogDQ5hVv3WMjvN4OXS57s7GrOila2sCnc4zXYxR9yDWHaBm2ZTvstnn48fQ1TFuoiqEHl4+7L3ZausdUsLZK/Ivo0TTECiHZta8s5nzOn1yecx34e7dKzGyAIkO884X+by8OsFVhzSiVjHs2+kTLD2z2KcJ4N3Ld2O7QzYL8EWPLyEZiO8lMNBcpn7Ur/Fd6K7uckp+GXB3eP/uGLtsgydl3Di7+QjlTWvfzUENVjMVUDQf3u5murw7dMdHYVQ8uzufG2TcUwRW1rZtlHHQG7/dIQMoy4aO5ufFaCF5t/ey9tWtXFfT01un02HyNjl5Xa7BWIc9P46lfvon3Om0BFOfd/qPlwtXT71lLBsEVbL14dXL5f31eHx9/XX5cfcUUm07N++a4XEQXJPBI7VSprgrAHQ+oEurBxzy00aQaFipC2CtNK0SBXOylBtxLCaXYJn+4Wdg7ELo08zk5nQDaDsi8lqAOLieENsAYLRasim9LPjU1VG1yyI/SBG1Snf8FsVGzXFSRIsTWKpvfiOiJZ4ui9A3T6DU6JtSCNvEQauciJaTMmoSNytMLyoK7RPNB+tAXTI5AGiwdx2jfTIRti1La1LHtH06VtCkkjkxUUibQqfJ+yYqdlAXA/RkGlTa8q4u2EwubwQhLqfZlJmQvY3UTWmWOdNXDqEvDa/ZnJD6SKPWbs6Xwf3um+bBOkb3AtDBHtNszP8FWI4NbAohtH26bqI5wP1uVRtuWRRoPUsFhSUBtWijalSjS2aaXFFS2ZUajItj1E6sskcyyyG0fL9JGZW2oll8WoOu0wplc2p0iQ+aprCpbNf34TvCEY5whCMc4QhHOML/BeS5wOEfhLD4w2BZVYqYhRFSNrxCYhMKrw/QRazlg/Li/KCBMFUQFl5TyoyZ7bKZxhLD8RAZVKgLl6BQDvgoj694NEjZ6UYr3ySmzRW+l+32jRKoQXG+V0R4zAIc4Qh/EPwPymIqYrcKlXsAAAAASUVORK5CYII=" 
		alt="whatsapp us"/>
		</a>
<p><b>7655465436</b></p>
		</div>
</body>
</html>





